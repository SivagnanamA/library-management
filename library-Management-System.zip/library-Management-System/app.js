
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const md5 = require('md5');
const saltRounds = 10;
// app.use(express.static('public'));

console.log('weak password hash' + md5("123456"))
console.log('Strong password hash' + md5("shhkslkstrrvdgg123"))
const app = express();
console.log(process.env.API_kEY);
app.use(express.static("public"));
app.set('view engine','ejs');
app.use(bodyParser.urlencoded({extended:true}));
mongoose.connect("mongodb://localhost:27017/userDB",{useNewUrlParser:true});
const userSchema = new mongoose.Schema({
    email:String,
    password:String,
    regno: String,
    studentname: String,
    course: String,
    batch:String,
    date: Number,
    paymentby: String,
    paymentfor: String,

})

const User = new mongoose.model("User",userSchema);

app.get("/",function(req,res){
    res.render("home")
})


app.get("/userlogin",function(req,res){
    res.render("userlogin")
})
app.get("/userregister",function(req,res){
    res.render("userregister")
})
app.get("/cashierregister",function(req,res){
    res.render("cashierregister")
})
app.get("/cashier",function(req,res){
    res.render("cashier")
})
app.get("/cashierlogin",function(req,res){
    res.render("cashierlogin")
})
app.get("/user",function(req,res){
    res.render("user");
})
app.get("/add",function(req,res){
    res.render("addpayment");
})

app.get("/books", (req, res) => {
    res.render("books")
  })
app.post("/userregister",function(req,res){
    bcrypt.hash(req.body.password,saltRounds,function(err,hash){
    const newUser = new User({
        email:req.body.email,
        regno: req.body.regno,
        studentname: req.body.studentname,
        course: req.body.course,
        batch: req.body.batch,
        password:hash
    })
    newUser.save(function(err){
        if(err){
            console.log(err)
        }
        else{
            res.render("userhome");
        }
    })
})
})

// app.post("/books",function(req,res){
//     bcrypt.hash(req.body.password,saltRounds,function(err,hash){
//     const newUser = new User({
//         email:req.body.email,
//         regno: req.body.regno,
//         studentname: req.body.studentname,
//         course: req.body.course,
//         batch: req.body.batch,
//         password:hash
//     })
//     newUser.save(function(err){
//         if(err){
//             console.log(err)
//         }
//         else{
//             res.render("books");
//         }
//     })
// })
// })


app.post("/add",function(req,res){
    bcrypt.hash(req.body.password,saltRounds,function(err,hash){
    const newUser = new User({
        email:req.body.email,
        regno: req.body.regno,
        studentname: req.body.studentname,
        course: req.body.course,
        batch: req.body.batch,
        password:hash
    })
    newUser.save(function(err){
        if(err){
            console.log(err)
        }
        else{
            res.render("userhome");
        }
    })
})
})
app.post("/cashierregister",function(req,res){
    bcrypt.hash(req.body.password,saltRounds,function(err,hash){
    const newUser = new User({
        email:req.body.email,
        password:hash,
        
    })
    newUser.save(function(err){
        if(err){
            console.log(err)
        }
        else{
            res.render("cashierhome");
        }
    })
})
})

app.post("/userlogin",function(req,res){
    const email = req.body.email;
    const password = req.body.password
    User.findOne({email:email},function(err,foundUser){
     if(err){
        console.log(err)
     }
     else{
        if(foundUser){
            bcrypt.compare(password,foundUser.password,function(err,result){
                if(result===true){
                    res.render("userhome")
                }
            })
        }
     }
})
})
app.post("/cashierlogin",function(req,res){
    const email = req.body.email;
    const password = req.body.password
    User.findOne({email:email},function(err,foundUser){
     if(err){
        console.log(err)
     }
     else{
        if(foundUser){
            bcrypt.compare(password,foundUser.password,function(err,result){
                if(result===true){
                    res.render("cashierhome")
                }
            })
        }
     }
})
})


app.post("/updatepayment", function (req, res) {
    var user = new User({
        username:req.body.username,
        win:req.body.win,
        lose:req.body.lose,
        draw:req.body.draw  
    });

    Users.findOne({ username : req.params.username }, function(error, user) {
    if (error || !user) {
      res.send({ error: error });
    } else {
       user.update(function (err, user) {
       if (err) res.json(err)
        req.session.loggedIn = true;
        res.redirect('/user/' + user.username);
        });
    }
    });
});




app.listen(3000,function(){
    console.log("server is started at port 3000")
})